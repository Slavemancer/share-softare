Read me
-------
To prepare a translation:
- Translate English.lng and test it. Do not localize special chars:
  \n \r \t %s %d.
- Include information about you in [About] section.
- Mask email by replacing '@' with '(at)'.
- Name your file with ASCII characters only.

Versions history
----------------
6.7.1.1
+ cap 166 113 804 816-829
* delete: cap 741-744

6.5.4 
+ cap 218

6.5.3
+ cap 823-827
